-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Máquina: localhost
-- Data de Criação: 04-Jan-2014 às 14:08
-- Versão do servidor: 5.5.34-cll
-- versão do PHP: 5.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de Dados: `Nome_do_seu_banco_de_dados`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `login` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `admin`
--

INSERT INTO `admin` (`login`, `senha`) VALUES
('Seu login admin', 'Sua senha admin');

-- --------------------------------------------------------

--
-- Estrutura da tabela `estatisticas`
--

CREATE TABLE IF NOT EXISTS `estatisticas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visitas` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `extrato`
--

CREATE TABLE IF NOT EXISTS `extrato` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(30) NOT NULL,
  `detalhe` text NOT NULL,
  `valor` int(5) NOT NULL,
  `data` bigint(20) NOT NULL,
  `downline` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `indicados`
--

CREATE TABLE IF NOT EXISTS `indicados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(30) NOT NULL,
  `indicador_nivel1` varchar(30) NOT NULL,
  `indicador_nivel2` varchar(30) NOT NULL,
  `indicador_nivel3` varchar(30) NOT NULL,
  `indicador_nivel4` varchar(30) NOT NULL,
  `indicador_nivel5` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=283 ;

--
-- Extraindo dados da tabela `indicados`
--

INSERT INTO `indicados` (`id`, `login`, `indicador_nivel1`, `indicador_nivel2`, `indicador_nivel3`, `indicador_nivel4`, `indicador_nivel5`) VALUES
(277, 'dedei', 'danilo', '', '', '', ''),
(278, 'angela', 'dedei', 'danilo', '', '', ''),
(279, 'gustavo', 'angela', 'dedei', 'danilo', '', ''),
(280, 'Daniloes', 'gustavo', 'angela', 'dedei', 'danilo', ''),
(281, 'alex', 'daniloes', 'gustavo', 'angela', 'dedei', 'danilo'),
(282, 'Lidersudeste', 'daniloes', 'gustavo', 'angela', 'dedei', 'danilo');

-- --------------------------------------------------------

--
-- Estrutura da tabela `msg`
--

CREATE TABLE IF NOT EXISTS `msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `de` varchar(30) NOT NULL,
  `para` varchar(30) NOT NULL,
  `assunto` varchar(200) NOT NULL,
  `texto` text NOT NULL,
  `data` bigint(30) NOT NULL,
  `status` enum('read','unread') NOT NULL,
  `situacao` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Extraindo dados da tabela `msg`
--

INSERT INTO `msg` (`id`, `de`, `para`, `assunto`, `texto`, `data`, `status`, `situacao`) VALUES
(3, 'administrador', 'todos', 'Fiquem atento', 'Por favor se liga', 1387497523, 'unread', 'importante'),
(4, 'dedei', 'admin', 'por', 'favor', 1387498112, 'unread', ''),
(5, 'dedei', 'Admin', 'teste', 'poeoeoeoeoeo', 1387498145, 'unread', ''),
(6, 'danilo', 'daniloes', 'Teste', 'mjdnckmnkdmcko', 1387572816, 'read', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamentos`
--

CREATE TABLE IF NOT EXISTS `pagamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(30) NOT NULL,
  `indicador` varchar(30) NOT NULL,
  `indicador_nivel` int(11) NOT NULL,
  `status` enum('nao pago','pendente','pago','recusado') NOT NULL,
  `comprovante` text NOT NULL,
  `hora` bigint(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1391 ;

--
-- Extraindo dados da tabela `pagamentos`
--

INSERT INTO `pagamentos` (`id`, `login`, `indicador`, `indicador_nivel`, `status`, `comprovante`, `hora`) VALUES
(1336, 'master', 'clairgeremia', 5, 'pago', '', 0),
(1341, 'dallainfo', 'clairgeremia', 5, 'pago', '', 0),
(1342, 'dallainfo', '', 4, 'nao pago', '', 0),
(1343, 'dallainfo', '', 3, 'nao pago', '', 0),
(1344, 'dallainfo', '', 2, 'nao pago', '', 0),
(1345, 'dallainfo', '', 1, 'nao pago', '', 0),
(1346, 'terezinhardc', 'dallainfo', 5, 'pago', '178906.jpg', 1385057647),
(1347, 'terezinhardc', 'clairgeremia', 4, 'pago', '', 0),
(1348, 'terezinhardc', '', 3, 'nao pago', '', 0),
(1349, 'terezinhardc', '', 2, 'nao pago', '', 0),
(1350, 'terezinhardc', '', 1, 'nao pago', '', 0),
(1351, 'valterdiamante', 'terezinhardc', 5, 'pago', 'dietamuitofacil_03.jpg', 1385083820),
(1352, 'valterdiamante', 'dallainfo', 4, 'nao pago', '', 0),
(1353, 'valterdiamante', 'clairgeremia', 3, 'nao pago', '', 0),
(1354, 'valterdiamante', '', 2, 'nao pago', '', 0),
(1355, 'valterdiamante', '', 1, 'nao pago', '', 0),
(1356, 'iresgeremia', 'valterdiamante', 5, 'nao pago', '', 0),
(1357, 'iresgeremia', 'terezinhardc', 4, 'nao pago', '', 0),
(1358, 'iresgeremia', 'dallainfo', 3, 'nao pago', '', 0),
(1359, 'iresgeremia', 'clairgeremia', 2, 'nao pago', '', 0),
(1360, 'iresgeremia', '', 1, 'nao pago', '', 0),
(1361, 'dedei', 'danilo', 5, 'nao pago', '', 0),
(1362, 'dedei', '', 4, 'nao pago', '', 0),
(1363, 'dedei', '', 3, 'nao pago', '', 0),
(1364, 'dedei', '', 2, 'nao pago', '', 0),
(1365, 'dedei', '', 1, 'nao pago', '', 0),
(1366, 'angela', 'dedei', 5, 'pago', '', 0),
(1367, 'angela', 'danilo', 4, 'nao pago', '', 0),
(1368, 'angela', '', 3, 'nao pago', '', 0),
(1369, 'angela', '', 2, 'nao pago', '', 0),
(1370, 'angela', '', 1, 'nao pago', '', 0),
(1371, 'gustavo', 'angela', 5, 'nao pago', '', 0),
(1372, 'gustavo', 'dedei', 4, 'pago', '', 0),
(1373, 'gustavo', 'danilo', 3, 'nao pago', '', 0),
(1374, 'gustavo', '', 2, 'nao pago', '', 0),
(1375, 'gustavo', '', 1, 'nao pago', '', 0),
(1376, 'Daniloes', 'gustavo', 5, 'nao pago', '', 0),
(1377, 'Daniloes', 'angela', 4, 'nao pago', '', 0),
(1378, 'Daniloes', 'dedei', 3, 'pago', '', 0),
(1379, 'Daniloes', 'danilo', 2, 'nao pago', '', 0),
(1380, 'Daniloes', '', 1, 'nao pago', '', 0),
(1381, 'alex', 'daniloes', 5, 'pago', '', 0),
(1382, 'alex', 'gustavo', 4, 'pago', 'chuva.jpg', 1387507984),
(1383, 'alex', 'angela', 3, 'pago', '', 0),
(1384, 'alex', 'dedei', 2, 'pago', '', 0),
(1385, 'alex', 'danilo', 1, 'pago', 'image_get.jpg', 1387508019),
(1386, 'Lidersudeste', 'daniloes', 5, 'nao pago', '', 0),
(1387, 'Lidersudeste', 'gustavo', 4, 'nao pago', '', 0),
(1388, 'Lidersudeste', 'angela', 3, 'nao pago', '', 0),
(1389, 'Lidersudeste', 'dedei', 2, 'pago', '', 0),
(1390, 'Lidersudeste', 'danilo', 1, 'pago', 'deposito.fw.png', 1387566641);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(20) NOT NULL,
  `senha` varchar(30) NOT NULL,
  `email` varchar(200) NOT NULL,
  `saldo` float(10,2) NOT NULL,
  `nome` varchar(60) NOT NULL,
  `dados_banco` varchar(50) NOT NULL,
  `dados_agencia` varchar(50) NOT NULL,
  `dados_tipoconta` enum('poupanca','corrente') NOT NULL,
  `dados_conta` varchar(50) NOT NULL,
  `dados_nome` varchar(80) NOT NULL,
  `dados_op` varchar(10) NOT NULL,
  `status` enum('pendente','ativo') NOT NULL,
  `pincode` int(20) NOT NULL,
  `skype` varchar(30) NOT NULL,
  `registro` bigint(20) NOT NULL,
  `facebook` varchar(200) NOT NULL,
  `pagseguro` varchar(155) NOT NULL,
  `moip` varchar(155) NOT NULL,
  `akatus` varchar(155) NOT NULL,
  `hits` varchar(30) NOT NULL,
  `nivel` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=311 ;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `login`, `senha`, `email`, `saldo`, `nome`, `dados_banco`, `dados_agencia`, `dados_tipoconta`, `dados_conta`, `dados_nome`, `dados_op`, `status`, `pincode`, `skype`, `registro`, `facebook`, `pagseguro`, `moip`, `akatus`, `hits`, `nivel`) VALUES
(300, 'Danilo', '123mudar', 'admin@admin.com.br', 120.00, 'Admin', 'Bradesco', '2429', 'corrente', '6367-3', '', '', 'ativo', 16, '', 0, '', 'importsmania@hotmail.com.br', '', '', '', 'admin'),
(305, 'dedei', '111213', 'jossinei_fox_@hotmail.com', 100.00, 'Jossinei Francisco Dos Santos', '', '', '', '', '', '', 'ativo', 1, 'jossinei_fox_@hotmail.com', 1387496278, 'https://www.facebook.com/jossinei.franciscodossantos', '', '', '', '', ''),
(306, 'angela', '111213', 'angelinha100@yahoo.com.br', 20.00, 'Angela Maria Souza dos Santos', '', '', '', '', '', '', 'ativo', 2, '', 1387507391, '', '', '', '', '', ''),
(307, 'gustavo', '111213', 'gustavo@iideia.com.br', 20.00, 'Gustavo Bolsoni', '', '', '', '', '', '', 'ativo', 1, '', 1387507594, 'https://www.facebook.com/gustavobolsoni16', '', '', '', '', ''),
(308, 'Daniloes', '111213', 'danilo@iideia.com.br', 20.00, 'Danilo Souza de Jesus Fonseca', '', '', '', '', '', '', 'ativo', 2, '', 1387507734, 'https://www.facebook.com/danilo.iideia', 'danilosouza@live.com', '', 'danilosouza@live.com', '', ''),
(309, 'alex', '111213', 'danilosouza@live.com', 0.00, 'Alex', '', '', '', '', '', '', 'ativo', 1, '', 1387507888, '', '', '', '', '', ''),
(310, 'Lidersudeste', 'eldorado', 'alexbrasil01@gmail.com', 0.00, 'Alex Oliveira', '', '', '', '', '', '', 'ativo', 0, '', 1387564906, 'https://www.facebook.com/Alexdesignerweb.com.br', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `visitantes`
--

CREATE TABLE IF NOT EXISTS `visitantes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL,
  `timestamp` bigint(20) NOT NULL,
  `referencia` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
