<div id="main-content">
			<!-- BEGIN PAGE CONTAINER-->
			<div class="container-fluid">
				<div class="row-fluid">
					<div class="span12">
						<div class="span6">
						<!-- BEGIN PAGE TITLE & BREADCRUMB-->
						<h3 class="page-title">
							Escritório Virtual
							<small> Painel de Controle </small>
						</h3>
						<ul class="breadcrumb">
							<li>
                                <a href="#"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
							</li>
                            <li>
                                <a href="index.php">Ciclo</a> <span class="divider">&nbsp;</span>
                            </li>
							<li><a href="#">Painel de Controle</a><span class="divider-last">&nbsp;</span></li>
						</ul>	
						</div>
						<div class="span12">
						<p>
                              <a href="index.php?view=adm"><button class="btn"><i class="icon-plus"></i> Administrar Usuários</button></a>
                              <a href="index.php?view=adm-pagamentos"><button class="btn btn-warning"><i class="icon-plus icon-white"></i> Administrar Pagamentos</button></a>
                              <a href="index.php?view=adm-mensagem"><button class="btn btn-inverse"><i class="icon-plus icon-white"></i> Administrar Mensagens</button></a>
                           </p>
						</div>
						<!-- END PAGE TITLE & BREADCRUMB-->
					</div>
				</div>
				<!-- BEGIN PAGE HEADER-->
				<div class="row-fluid">
					<div class="span12">
<div class="widget">
                        <div class="widget-title">
                            <h4><i class="icon-reorder"></i>Administrar Usuários</h4>
                        </div>
                        <div class="widget-body">
                            <div id="sample_1_wrapper" class="dataTables_wrapper form-inline" role="grid">
                            	<div class="row-fluid">
                            		<table class="table table-striped table-bordered dataTable" id="sample_1" aria-describedby="sample_1_info">
                            <thead>
                                <tr role="row">
                                	<th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_1" rowspan="1" colspan="1">Usuário</th>
                                	<th class="hidden-phone sorting" role="columnheader" tabindex="0" aria-controls="sample_1" rowspan="1" colspan="1">Senha</th>
                                	<th class="hidden-phone sorting" role="columnheader" tabindex="0" aria-controls="sample_1" rowspan="1" colspan="1">E-mail</th>
                                	<th class="hidden-phone sorting" role="columnheader" tabindex="0" aria-controls="sample_1" rowspan="1" colspan="1" >Valor Ganho</th>
                                	<th class="hidden-phone sorting" role="columnheader" tabindex="0" aria-controls="sample_1" rowspan="1" colspan="1">Ações</th></tr>
                            </thead>
                            
                        <tbody role="alert" aria-live="polite" aria-relevant="all">
                        <?php
                        $limite = 10;
						$pagina = $_GET['pag'];
						if(!isset($pagina) || empty($pagina))
						{
						$pagina = 1;
						}
						$inicio = ($pagina * $limite) - $limite; 
                        $sql=mysql_query("select * from usuarios order by id DESC LIMIT $inicio, $limite");
						while ($ver=mysql_fetch_array($sql)){
                         ?>	
                        		<tr class="gradeX odd">
                                    <td><?php echo $ver["login"]; ?></td>
                                    <td><?php echo $ver["senha"]; ?></td>
                                    <td><?php echo $ver["email"]; ?></td>
                                    <td>R$ <?php echo number_format($ver["saldo"],2,',','.');?></td>
                                    <td>
                                    	<?php if ($ver["status"]=="ativo"): ?>
										<a href="set.php?acao=bloquear_user&id=<?php echo $ver["id"]; ?>" class="label label-success">Bloquear</a>	
										<?php else: ?>
										<a href="set.php?acao=ativar_user&id=<?php echo $ver["id"]; ?>" class="label label-inverse">Ativar</a>
										<?php endif ?> 
                                    	<a href="set.php?acao=deletar_user&id=<?php echo $ver["id"]; ?>" class="label label-important">Deletar Usuário</a></td>
                                </tr>
                            <?php } ?>    
                                </tbody>
                                </table>
                                <?php 
												
												$consulta = mysql_query("SELECT id FROM usuarios");
												$total_registros = mysql_num_rows($consulta);
												$total_paginas = Ceil($total_registros / $limite);
												
												 ?>
                                <div class="row-fluid">
                                <div class="span6">
                                <div class="dataTables_info" id="sample_1_info">Mostrando 1 de <?php echo $total_paginas; ?> paginas, total de <?php echo $total_registros; ?> registros</div>
                                </div><div class="span6">
                                <div class="dataTables_paginate paging_bootstrap pagination">
                                <ul>
                                <?php
echo "<li class='prev'><a href='index.php?view=adm&pag=1'>Primeira</a></li>";
    for($i=1; $i <= $total_paginas; $i++){
         if($pagina == $i)
         {
             echo '<li class="active"><a href="index.php?view=adm&pag='.$i.'">'.$i.'</a></li>';
         }
         else
         {
             echo '<li><a href="index.php?view=adm&pag='.$i.'">'.$i.'</a></li>';

         }
    }
echo '<li class="next"><a href="index.php?view=adm&pag='.$total_paginas.'">Última</a></li>';
?>
                                </ul>
                                </div>
                                </div>
                                </div>
                                </div>
                        </div>
                    </div>	
					</div>
				</div>
			</div>
</div>				