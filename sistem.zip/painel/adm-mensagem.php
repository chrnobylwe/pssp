<div id="main-content">
			<!-- BEGIN PAGE CONTAINER-->
			<div class="container-fluid">
				<div class="row-fluid">
					<div class="span12">
						<div class="span6">
						<!-- BEGIN PAGE TITLE & BREADCRUMB-->
						<h3 class="page-title">
							Escritório Virtual
							<small> Painel de Controle </small>
						</h3>
						<ul class="breadcrumb">
							<li>
                                <a href="#"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
							</li>
                            <li>
                                <a href="index.php">Ciclo</a> <span class="divider">&nbsp;</span>
                            </li>
							<li><a href="#">Painel de Controle</a><span class="divider-last">&nbsp;</span></li>
						</ul>	
						</div>
						<div class="span12">
						<p>
                              <a href="index.php?view=adm"><button class="btn"><i class="icon-plus"></i> Administrar Usuários</button></a>
                              <a href="index.php?view=adm-pagamentos"><button class="btn btn-warning"><i class="icon-plus icon-white"></i> Administrar Pagamentos</button></a>
                              <a href="index.php?view=adm-mensagem"><button class="btn btn-inverse"><i class="icon-plus icon-white"></i> Administrar Mensagens</button></a>
                           </p>
						</div>
						<!-- END PAGE TITLE & BREADCRUMB-->
					</div>
				</div>
				<!-- BEGIN PAGE HEADER-->
				<div class="row-fluid">
					<div class="span12">
						<div class="widget">
							<div class="widget-title">
								<h4><i class="icon-reorder"></i> Enviar Mensagens</h4>
							</div>
							<div class="widget-body">
							<?php
		if(isSet($_POST['para']))
			{
			
			$recebe = mysql_real_escape_string($_POST['para']);
			$assunto = htmlspecialchars(mysql_real_escape_string($_POST['assunto']));
			$texto =  htmlspecialchars(mysql_real_escape_string($_POST['msg']));
			$situacao = mysql_real_escape_string($_POST['situacao']);
			$dt = time();
			$inserir = mysql_query("INSERT INTO msg (id,de,para,assunto,texto,data,status, situacao) VALUES (NULL, 'administrador', '$recebe', '$assunto', '$texto', '$dt', 'unread','$situacao');") or die (mysql_error());
			
			if ($inserir){
			?>
			<br>
			<div class="alert alert-block alert-success fade in">
			<strong>Sua mensagem foi enviada para <font color=darkred><?php echo $recebe;?></font></strong></div>
		
			<?php
			}
			}
			else
			{
		?>
		<br>
		<div class="alert alert-block alert-success fade in">
		<form method=post>
		<div class="control-group">
                                    <label class="control-label">Para</label>
                                    <div class="controls">
                                    	<input type="text"  name="para" value="todos" class="input-xxlarge">
                                    </div>
                                </div>
        <div class="control-group">
                                    <label class="control-label">Assunto</label>
                                    <div class="controls">
                                    	<input type="text"   name="assunto" placeholder="Assunto da mensagem" class="input-xxlarge">
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label">Situação</label>
                                    <div class="controls">
                                    	<select name="situacao">
                                    		<option value="importante">importante</option>
                                    		<option value="informativo">informativo</option>
                                    		<option value="atualizacao">atualizacao</option>
                                    		<option value="error">error</option>
                                    	</select>
                                    </div>
                                </div>
       <div class="control-group">
                                    <label class="control-label">Mensagem</label>
                                    <div class="controls">
                                    	<textarea cols="82" class="input-xxlarge" name="msg" placeholder="Mensagem a ser enviada"></textarea>
                                    </div>
                                </div>
<div class="form-actions">
                                    <input type="submit" value="Enviar Mensagem" name="ok" class="btn blue">
                                </div>
		</form>
		</div>
		<?php
		}
		?>	
							</div>
						</div>
<div class="widget">
                        <div class="widget-title">
                            <h4><i class="icon-reorder"></i>Administrar Mensagem</h4>
                        </div>
                        <div class="widget-body">
                            <div id="sample_1_wrapper" class="dataTables_wrapper form-inline" role="grid">
                            	<div class="row-fluid">
                            		<table class="table table-striped table-bordered dataTable" id="sample_1" aria-describedby="sample_1_info">
                            <thead>
                                <tr role="row">
                                	<th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_1" rowspan="1" colspan="1">De</th>
                                	<th class="hidden-phone sorting" role="columnheader" tabindex="0" aria-controls="sample_1" rowspan="1" colspan="1">Para</th>
                                	<th class="hidden-phone sorting" role="columnheader" tabindex="0" aria-controls="sample_1" rowspan="1" colspan="1">Data</th>
                                	<th class="hidden-phone sorting" role="columnheader" tabindex="0" aria-controls="sample_1" rowspan="1" colspan="1" >Assunto</th>
                                	<th class="hidden-phone sorting" role="columnheader" tabindex="0" aria-controls="sample_1" rowspan="1" colspan="1">Ações</th></tr>
                            </thead>
                            
                        <tbody role="alert" aria-live="polite" aria-relevant="all">
                        <?php
                        $limite = 10;
						$pagina = $_GET['pag'];
						if(!isset($pagina) || empty($pagina))
						{
						$pagina = 1;
						}
						$inicio = ($pagina * $limite) - $limite; 
                        $sql=mysql_query("select * from msg order by id DESC LIMIT $inicio, $limite");
						while ($ver=mysql_fetch_array($sql)){
                         ?>	
                        		<tr class="gradeX odd">
                                    <td><?php echo $ver["de"]; ?></td>
                                    <td><?php echo $ver["para"]; ?></td>
                                    <td><?php echo date("d/m/Y H:i:s", $ver["data"]);?></td>
                                    <td><?php echo $ver["assunto"]; ?></td>
                                    <td>
										<a href="set.php?acao=deletar_mensagem&id=<?php echo $ver["id"]; ?>" class="label label-important">Deletar Mensagem</a>	
</td>
                                </tr>
                            <?php } ?>    
                                </tbody>
                                </table>
                                <?php 
												
												$consulta = mysql_query("SELECT id FROM msg");
												$total_registros = mysql_num_rows($consulta);
												$total_paginas = Ceil($total_registros / $limite);
												
												 ?>
                                <div class="row-fluid">
                                <div class="span6">
                                <div class="dataTables_info" id="sample_1_info">Mostrando 1 de <?php echo $total_paginas; ?> paginas, total de <?php echo $total_registros; ?> registros</div>
                                </div><div class="span6">
                                <div class="dataTables_paginate paging_bootstrap pagination">
                                <ul>
                                <?php
echo "<li class='prev'><a href='index.php?view=adm-mensagem&pag=1'>Primeira</a></li>";
    for($i=1; $i <= $total_paginas; $i++){
         if($pagina == $i)
         {
             echo '<li class="active"><a href="index.php?view=adm-mensagem&pag='.$i.'">'.$i.'</a></li>';
         }
         else
         {
             echo '<li><a href="index.php?view=adm-mensagem&pag='.$i.'">'.$i.'</a></li>';

         }
    }
echo '<li class="next"><a href="index.php?view=adm-mensagem&pag='.$total_paginas.'">Última</a></li>';
?>
                                </ul>
                                </div>
                                </div>
                                </div>
                                </div>
                        </div>
                    </div>	
					</div>
				</div>
			</div>
</div>				